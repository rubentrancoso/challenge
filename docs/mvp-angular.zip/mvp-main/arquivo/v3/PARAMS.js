

const META_GRAPH_API_VERSION = "v18.0";
const APP_ID = "241096132329456";
const PAGE_ID = "123902623941802";
const APP_SECRET_KEY = "73a53cae0c9c1610ab005822d1687419";
const PAGE_ACCESSS_TOKEN = "EAADbRpFSZCZCABO5OHmE6NF1Nfm0ztfG3kBg8qI1QIDimXf" +
    "bBOmSpZArJA8MCTvP4vC2FGZCympKkiP8zgtiU58EOZCDMoyNxu189HZAeNgAVcdBFWVIUf" +
    "arr2jCbIXDR93YJrrabhmGJbmDoUv72d0K2ItJ3ULbZAsjcn6Cidy426Oc6joBlqDKl9owF" +
    "klagaHb9953bZCdOYfZA";
const WEBHOOK_VERIFY_TOKEN = "h7vlZW4Koy2qIQwUgc7jtc3CJM3tThWJ";
const HOT_MEDIA_ID = "18003901394111493"; // "18003901394111493";
const HOT_COMMENT = "example";
const HOT_COMMENT_REPLY = "te mandei no privado";
// const RECIPIENT_ID = "6969708829776358";
const PRIVATE_MESSAGE = "Aqui vai o link: https://rubentrancoso.com.br";

exports.META_GRAPH_API_VERSION = META_GRAPH_API_VERSION;
exports.APP_ID = APP_ID;
exports.PAGE_ID = PAGE_ID;
exports.APP_SECRET_KEY = APP_SECRET_KEY;
exports.PAGE_ACCESSS_TOKEN = PAGE_ACCESSS_TOKEN;
exports.WEBHOOK_VERIFY_TOKEN = WEBHOOK_VERIFY_TOKEN;
exports.HOT_MEDIA_ID = HOT_MEDIA_ID;
exports.HOT_COMMENT = HOT_COMMENT;
exports.HOT_COMMENT_REPLY = HOT_COMMENT_REPLY;
exports.PRIVATE_MESSAGE = PRIVATE_MESSAGE;

const MessageOriginEnum = Object.freeze({"comment": 1, "live_comment": 2});

exports.MessageOriginEnum = MessageOriginEnum;
