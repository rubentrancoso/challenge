/**
 * Import function triggers from their respective submodules:
 *
 * const {onCall} = require("firebase-functions/v2/https");
 * const {onDocumentWritten} = require("firebase-functions/v2/firestore");
 *
 * See a full list of supported triggers at https://firebase.google.com/docs/functions
 */

const {
  APP_SECRET_KEY,
  WEBHOOK_VERIFY_TOKEN,
  META_GRAPH_API_VERSION,
  PAGE_ID,
  PAGE_ACCESSS_TOKEN,
  HOT_MEDIA_ID,
  HOT_COMMENT,
  PRIVATE_MESSAGE,
  MessageOriginEnum,
} = require("./PARAMS");

const {onRequest} = require("firebase-functions/v2/https");
const {logger} = require("firebase-functions");
const crypto = require("crypto");
const axios = require("axios");

exports.instaNewComment = onRequest((request, response) => {
  try {
    logger.info("Received request", {structuredData: true, requestData: request.query});

    if (request.method === "GET") {
      // Trata solicitações GET
      const challenge = request.query["hub.challenge"];
      const receivedVerifyToken = request.query["hub.verify_token"];

      if (challenge && receivedVerifyToken === WEBHOOK_VERIFY_TOKEN) {
        response.send(challenge);
      } else {
        logger.error("Invalid request for GET method");
        response.status(400).send("Bad Request");
      }
    } else if (request.method === "POST") {
      const signature = request.headers["x-hub-signature-256"]?.split("sha256=")[1];
      const hash = crypto.createHmac("sha256", APP_SECRET_KEY)
          .update(request.rawBody, "utf8")
          .digest("hex");

      // logger.info("signature", signature);
      // logger.info("hash", hash);
      // logger.info("request.rawBody", request.rawBody);
      // logger.info("JSON.stringify(request.body)", JSON.stringify(request.body));
      if (signature && hash === signature) {
        logger.info("Valid signature. Processing payload.", JSON.stringify(request.body));

        router(MessageOriginEnum.comment, JSON.parse(request.body));

        response.status(200).send("OK");
      } else {
        logger.error("Invalid signature. Rejecting payload.");
        response.status(403).send("Forbidden: Invalid signature");
      }
    } else {
      logger.error("Unsupported HTTP method");
      response.status(405).send("Method Not Allowed");
    }
  } catch (error) {
    logger.error("Error in instaNewComment", error);
    response.status(500).send("Internal Server Error");
  }
});

/**
 * Add two numbers.
 * @param {number} origin The first number.
 * @param {number} payload The second number.
 */
function router(origin, payload) {
  try {
    // logger.info("payload.", JSON.stringify(payload));
    payload.entry.forEach( (entry) => {
      // logger.info("Entry.", JSON.stringify(entry));
      entry.changes.forEach( (change) => {
        logger.info("Change.", JSON.stringify(change));

        switch (origin) {
          case MessageOriginEnum.comment:
            // logger.info("MessageOriginEnum.comment");
            // logger.info("change.value.media.id", change.value.media.id);
            // logger.info("change.value.text.toLowerCase()", change.value.text.toLowerCase());
            if (
              ( change.value.media.id == HOT_MEDIA_ID ) &&
                            ( change.value.text.toLowerCase().includes(HOT_COMMENT) )
            ) {
              processHotCommentHook(change);
            }

            break;
          default:
        }
      });
    });
  } catch (error) {
    logger.error("Error in router", error);
  }
}

/**
 * Add two numbers.
 * @param {number} change The first number.
 */
function processHotCommentHook(change) {
  logger.info("Processing Hot Comment.");
  // logger.info("change.value.from.id", change.value.from.id);
  // logger.info("change.value.from.username", change.value.from.username);
  try {
    const recipientId = change.value.from.id;
    const recipientName = change.value.from.username;
    sendDM( recipientId, recipientName, PRIVATE_MESSAGE);
  } catch (error) {
    logger.error("Error in processHotCommentHook", error);
  }
}

/**
 * Add two numbers.
 * @param {number} recipientId The first number.
 * @param {number} recipientName The first number.
 * @param {number} message The first number.
 */
function sendDM(recipientId, recipientName, message) {
  // https://medium.com/@Astider/how-to-%E0%B8%AA%E0%B8%A3%E0%B9%89%E0%B8%B2%E0%B8%87-messenger-chatbot-%E0%B9%81%E0%B8%9A%E0%B8%9A-serverless-%E0%B8%94%E0%B9%89%E0%B8%A7%E0%B8%A2-google-firebase-908c3eaba67e

  logger.info("Processing sendDM");

  try {
    axios({
      method: "POST",
      url: "https://graph.facebook.com/" + META_GRAPH_API_VERSION+ "/" + PAGE_ID + "/messages",
      params: {
        "access_token": PAGE_ACCESSS_TOKEN,
        "recipient": "{ 'id' : '" + recipientId + "' }",
        "message": "{ 'text' : 'teste 123 http://exemplo.com' }",
      },
    });

    logger.info("Called Graph API");
  } catch (error) {
    logger.error("Error in sendDM", error);
  }
}
