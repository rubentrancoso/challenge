/**
 * Import function triggers from their respective submodules:
 *
 * const {onCall} = require("firebase-functions/v2/https");
 * const {onDocumentWritten} = require("firebase-functions/v2/firestore");
 *
 * See a full list of supported triggers at https://firebase.google.com/docs/functions
 */

// Create and deploy your first functions
// https://firebase.google.com/docs/functions/get-started

const { 
    APP_SECRET_KEY, 
    APP_ID,
    WEBHOOK_VERIFY_TOKEN,
    META_GRAPH_API_VERSION,
    PAGE_ID,
    PAGE_ACCESSS_TOKEN,
    HOT_MEDIA_ID,
    HOT_COMMENT,
    HOT_COMMENT_REPLY,
    PRIVATE_MESSAGE,
    MessageOriginEnum
} = require('./PARAMS');

const {onRequest} = require("firebase-functions/v2/https");
const logger = require("firebase-functions/logger");
const crypto = require('crypto');
const FB = require('fb');

FB.options({version: META_GRAPH_API_VERSION});

// FB.init({
//     appId      : APP_ID,
//     status     : true,
//     xfbml      : true,
//     version    : META_GRAPH_API_VERSION 
//   });

exports.helloWorld = onRequest((request, response) => {
  logger.info("Hello logs!", {structuredData: true});
  response.send("Hello from Firebase!");
});

exports.instaNewComment = onRequest((request, response) => {
    try {
        logger.info("Received request", {structuredData: true, requestData: request.query});

        if (request.method === 'GET') {
            // Trata solicitações GET
            const challenge = request.query['hub.challenge'];
            const receivedVerifyToken = request.query['hub.verify_token'];

            if (challenge && receivedVerifyToken === WEBHOOK_VERIFY_TOKEN) {
                response.send(challenge);
            } else {
                logger.error("Invalid request for GET method");
                response.status(400).send("Bad Request");
            }
        } else if (request.method === 'POST') {
            // Trata solicitações POST
            const signature = request.headers['x-hub-signature-256']?.split('sha256=')[1];
            const hash = crypto.createHmac('sha256', APP_SECRET_KEY)
                               .update(request.rawBody, 'utf8')
                               .digest('hex');
        
            //logger.info("signature", signature);
            //logger.info("hash", hash);
            //logger.info("request.rawBody", request.rawBody);
            //logger.info("JSON.stringify(request.body)", JSON.stringify(request.body));
            if (signature && hash === signature) {
                logger.info("Valid signature. Processing payload.", JSON.stringify(request.body));

                router(MessageOriginEnum.comment, JSON.parse(request.body)); 

                response.status(200).send("OK");
            } else {
                logger.error("Invalid signature. Rejecting payload.");
                response.status(403).send("Forbidden: Invalid signature");
            }
        } else {
            // Trata outros métodos HTTP
            logger.error("Unsupported HTTP method");
            response.status(405).send("Method Not Allowed");
        }
    } catch (error) {
        logger.error("Error in instaNewComment", error);
        response.status(500).send("Internal Server Error");
    }
});

function router(origin, payload) {
    try {
        //logger.info("payload.", JSON.stringify(payload));
        payload.entry.forEach( function(entry) {
            //logger.info("Entry.", JSON.stringify(entry));
            entry.changes.forEach( function(change) {
                logger.info("Change.", JSON.stringify(change));

                switch(origin) {
                    case MessageOriginEnum.comment:
                        // logger.info("MessageOriginEnum.comment");
                        // logger.info("change.value.media.id", change.value.media.id);
                        // logger.info("change.value.text.toLowerCase()", change.value.text.toLowerCase());
                        if (
                            ( change.value.media.id == HOT_MEDIA_ID ) &&
                            ( change.value.text.toLowerCase().includes(HOT_COMMENT) )
                        ) {
                            processHotCommentHook(change);
                        }
                    
                        break;
                    default:
                        // code block
                };

            });
        });
    } catch(error) {
        logger.error("Error in router", error);
    }

}

function processHotCommentHook(change) {

    logger.info("Processing Hot Comment.");
    // logger.info("change.value.from.id", change.value.from.id);
    // logger.info("change.value.from.username", change.value.from.username);
    // try {
        // var recipient_id = change.value.from.id;
        // var recipient_name = change.value.from.username;
        // sendDM( recipient_id, recipient_name, PRIVATE_MESSAGE);
    // } catch(error) {
    //     logger.error("Error in processHotCommentHook", error);
    // }

    // Reply
    //     META_GRAPH_API_VERSION
    //     input.comment_id
    //     input.from_username
    //     PAGE_ACCESSS_TOKEN
    //     var message = '@fulano enviei o link no privado'; // HOT_COMMENT_REPLY
    //     var response = { 'message': message };

}

function sendDM(recipient_id, recipient_name, message) {

    // https://www.npmjs.com/package/fb

    logger.info("Processing sendDM");

    // try {
    //     FB.setAccessToken(PAGE_ACCESSS_TOKEN);
    //     FB.api(
    //         PAGE_ID + '/messages',
    //         'post',
    //         { message: 'teste' },
    //         function (response) {
    //             console.log(response);
    //         }
    //     );
    // } catch(error) {
    //     logger.error("Error in sendDM", error);
    // }

}