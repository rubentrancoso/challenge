const {
  APP_SECRET_KEY,
  WEBHOOK_VERIFY_TOKEN,
  META_GRAPH_API_VERSION,
  PAGE_ID,
  PAGE_ACCESSS_TOKEN,
  HOT_MEDIA_ID,
  HOT_COMMENT,
  HOT_COMMENT_REPLY,
  PRIVATE_MESSAGE_TEMPLATE,
  PRIVATE_TEST_MESSAGE_TEMPLATE,
  MessageOriginEnum,
} = require("./PARAMS");

const {onRequest} = require("firebase-functions/v2/https");
const {logger} = require("firebase-functions");
const crypto = require("crypto");
const axios = require("axios");

// exports.helloWorld = onRequest((request, response) => {
//   logger.info("Hello logs!", {structuredData: true});
//   response.send("Hello from Firebase!");
// });

/**
 * Cloud Function to handle new Instagram comments.
 */
exports.instaNewComment = onRequest((request, response) => {
  try {
    logger.info("Received request", {structuredData: true, requestData: request.query});

    if (request.method === "GET") {
      // Handle verification of the webhook
      const challenge = request.query["hub.challenge"];
      const receivedVerifyToken = request.query["hub.verify_token"];

      if (challenge && receivedVerifyToken === WEBHOOK_VERIFY_TOKEN) {
        response.send(challenge);
      } else {
        logger.error("Invalid GET request: Token verification failed");
        response.status(400).send("Bad Request");
      }
    } else if (request.method === "POST") {
      // Handle new comments
      logger.info("rawBody base64:", request.rawBody.toString("base64"));
      const signature = request.headers["x-hub-signature-256"] ?
        request.headers["x-hub-signature-256"].split("sha256=")[1] :
        null;
      const hash = crypto.createHmac("sha256", APP_SECRET_KEY)
          .update(request.rawBody, "utf8")
          .digest("hex");

      if (signature && hash === signature) {
        logger.info("Valid signature. Processing payload.");
        router(MessageOriginEnum.comment, request.body);
        response.status(200).send("OK");
      } else {
        logger.error("Invalid POST request: Signature mismatch");
        response.status(403).send("Forbidden: Invalid signature");
      }
    } else {
      logger.error("Unsupported HTTP method");
      response.status(405).send("Method Not Allowed");
    }
  } catch (error) {
    logger.error("Error in instaNewComment function", error);
    response.status(500).send("Internal Server Error");
  }
});

/**
 * Routes the incoming webhook event to the appropriate handler.
 * @param {MessageOriginEnum} origin The origin of the message.
 * @param {Object} payload The payload of the webhook event.
 */
function router(origin, payload) {
  try {
    payload.entry.forEach((entry) => {
      entry.changes.forEach((change) => {
        logger.info("Change detected:", JSON.stringify(change));
        if (origin === MessageOriginEnum.comment) {
          processChange(change);
        }
      });
    });
  } catch (error) {
    logger.error("Error in router function", error);
  }
}

/**
 * Processes each change detected in the webhook event.
 * Determines whether the change is a test case or a real comment
 * and calls the appropriate function to handle it.
 * @param {Object} change The change object from the webhook event payload.
 */
function processChange(change) {
  const isTest = change.value.media.id === "123123123" && change.value.text === "This is an example.";
  const isHotComment = change.value.media.id === HOT_MEDIA_ID && change.value.text.toLowerCase().includes(HOT_COMMENT);

  if (isTest || isHotComment) {
    processHotCommentHook(change, isTest);
  }
}

/**
 * Processes a comment that matches specific criteria.
 * @param {Object} change The change data from the webhook event.
 * @param {Boolean} isTest Indicates if the change is a test case.
 */
function processHotCommentHook(change, isTest) {
  logger.info("Processing Hot Comment, Test:", isTest);
  try {
    const commentId = isTest ? "17993724233237887" : change.value.id;
    const recipientId = isTest ? "6969708829776358" : change.value.from.id;
    const recipientName = isTest ? "leadcentral (test)" : change.value.from.username;
    const messageTemplate = isTest ? PRIVATE_TEST_MESSAGE_TEMPLATE : PRIVATE_MESSAGE_TEMPLATE;

    sendDM(recipientId, recipientName, messageTemplate);
    replyComment(commentId, recipientName, HOT_COMMENT_REPLY);
  } catch (error) {
    logger.error("Error in processHotCommentHook function", error);
  }
}

/**
 * Sends a Direct Message to a specified recipient.
 * @param {string} recipientId The ID of the recipient.
 * @param {string} recipientName The name of the recipient.
 * @param {string} messageTemplate The template for the message to be sent.
 */
function sendDM(recipientId, recipientName, messageTemplate) {
  logger.info("Sending Direct Message");
  const message = require("util").format(messageTemplate, recipientName);
  try {
    const url = `https://graph.facebook.com/${META_GRAPH_API_VERSION}/${PAGE_ID}/messages`;
    axios({
      method: "POST",
      url: url,
      params: {
        "access_token": PAGE_ACCESSS_TOKEN,
        "recipient": `{ 'id' : '${recipientId}' }`,
        "message": `{ 'text' : '${message}' }`,
      },
    }).then(() => {
      logger.info("(sendDM) Graph API call successful");
    }).catch((error) => {
      logger.error("(sendDM) Graph API call failed", error);
    });
  } catch (error) {
    logger.error("Error in sendDM function", error);
  }
}

// Corrected JSDoc documentation and updated string concatenation
/**
   * bla bla bla.
   * @param {string} commentId The ID of the recipient.
   * @param {string} recipientName The name of the recipient.
   * @param {string} messageTemplate The message to be sent.
   */
function replyComment(commentId, recipientName, messageTemplate) {
  logger.info("Processing replyComment");
  const message = require("util").format(messageTemplate, recipientName);
  try {
    // Using template literals for URL and parameters
    const url = `https://graph.facebook.com/${META_GRAPH_API_VERSION}/${commentId}/replies`;
    axios({
      method: "POST",
      url: url,
      params: {
        "access_token": PAGE_ACCESSS_TOKEN,
      },
      data: {
        message: message,
      },
    }).then(() => {
      logger.info("(replyComment) Successfully called Graph API");
    }).catch((error) => {
      logger.error("(replyComment) Error calling Graph API", error);
    });
  } catch (error) {
    logger.error("Error in sendDM", error);
  }
}

