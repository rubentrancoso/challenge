import { Component, inject } from '@angular/core';
import { MemberService } from 'src/app/services/member.service';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css'],
})
export class LoginPageComponent {
  memberService = inject(MemberService);
  user$ = this.memberService.user$;
}
