import { Component, inject } from '@angular/core';
import { DocumentData } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { MemberService } from 'src/app/services/member.service';

@Component({
  selector: 'app-member-page',
  templateUrl: './member-page.component.html',
  styleUrls: ['./member-page.component.css'],
})
export class MemberPageComponent {
  memberService = inject(MemberService);
  messages$ = this.memberService.loadMessages() as Observable<DocumentData[]>;
  user$ = this.memberService.user$;
  text = '';

  sendTextMessage() {
    this.memberService.saveTextMessage(this.text);
    this.text = '';
  }

  uploadImage(event: any) {
    const imgFile: File = event.target.files[0];
    if (!imgFile) {
      return;
    }
    this.memberService.saveImageMessage(imgFile);
  }
}
