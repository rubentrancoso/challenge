import { Component, inject } from '@angular/core';
import { MemberService } from 'src/app/services/member.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent {  
  memberService = inject(MemberService);
  user$ = this.memberService.user$;
}
