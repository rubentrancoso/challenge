export const environment = {
  production: true,
  mode: "prod",
  firebase: {
    apiKey: "AIzaSyC0Zu1Bs04zDXOofrdVP13l21Kks8MVJ50",
    authDomain: "lead-central-3e4a2.firebaseapp.com",
    projectId: "lead-central-3e4a2",
    storageBucket: "lead-central-3e4a2.appspot.com",
    messagingSenderId: "1023903828227",
    appId: "1:1023903828227:web:827c92b7f35d16028ac136",
    measurementId: "G-KW0G0MZE9V"
  }
};