export const environment = {
  production: false,
  mode: "local",
  firebase: {
    apiKey: "AIzaSyCt5B8Xqe3LtY4UYCyun1dqhA4JsnQQB94",
    authDomain: "lead-central-dev-18936.firebaseapp.com",
    projectId: "lead-central-dev-18936",
    storageBucket: "lead-central-dev-18936.appspot.com",
    messagingSenderId: "242807473335",
    appId: "1:242807473335:web:133275ffe47e9bf6b73932",
    measurementId: "G-05G68777J5"
  }
};